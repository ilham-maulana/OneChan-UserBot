from time import sleep
from userbot.events import register


@register(outgoing=True, pattern='^.fl(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("Sedang Memulai. Silahkan Tunggu")
    sleep(1)
    await typew.edit("0%")
    number = 1
    await typew.edit(str(number) + "% \n▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n█████████████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n██████████████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████████▊")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n███████████████▉")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████████")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████████▎")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████████▍")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████████▌")
    number = number + 1
    sleep(0.01)
    await typew.edit(str(number) + "% \n████████████████▌")
    sleep(1)
    await typew.edit("Ngapain Lu Nungguin Sih Goblok")
    # I did it for two hours :D just ctrl+c - crtl+v
