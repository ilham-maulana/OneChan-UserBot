            OneChan-UserBot

<p align="left"><a href="https://heroku.com/deploy?template=https://github.com/Ilham94/UserBot/tree/sql-extended"> <img src="https://telegra.ph/file/8438e16c058657f482238.jpg" alt="Deploy to Heroku" /></a></p>

## Generate String Session

Run on Repl.it:
<p><a href="http://dclxvi.anggar96s.repl.run"> <img src="https://img.shields.io/badge/run-string__session.py-blue?style=for-the-badge&logo=repl.it" alt="Generate String Session" /></a></p>

## Useful guides

* [Deploy to Heroku](https://telegra.ph/How-to-host-a-Telegram-Userbot-11-02)
* [Setup Google Drive](https://telegra.ph/How-To-Setup-Google-Drive-04-03)
* [Setup LastFM](https://telegra.ph/How-to-set-up-LastFM-module-for-Paperplane-userbot-11-02)

## Credits

Thanks for all : 
* [kandnub](https://github.com/kandnub) - TG-UserBot
* [AdekMaulana](https://github.com/adekmaulana) - ProjectBish
* [GengKapak](https://github.com/GengKapak/DCLXVI/graphs/contributors) -DCLXVI
* [aone-id](https://github.com/aone-id/aone-kangbot) -aone-kangbot
* [moveAngel](https://github.com/MoveAngel) - MoveAngel
